# randomWords.py
# Eamonn Godfrey
# 13214814
# 15/07/21

import random

words = ["return", "random", "description", "set", "control", "shift", "alternative", "basket", "phone", "super", "course", "get", "attain", "state", "uniform", "triangle", "nominal", "last"]

random.shuffle(words)
print(words)
